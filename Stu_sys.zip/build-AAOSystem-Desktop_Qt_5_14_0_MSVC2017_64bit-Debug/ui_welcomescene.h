/********************************************************************************
** Form generated from reading UI file 'welcomescene.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WELCOMESCENE_H
#define UI_WELCOMESCENE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WelcomeScene
{
public:
    QFormLayout *formLayout;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_7;
    QLabel *labWelcome;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QStackedWidget *stackedWidget;
    QWidget *page0;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QLabel *label_3;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *page0_number;
    QLineEdit *page0_password;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QVBoxLayout *verticalLayout_3;
    QPushButton *page0_login;
    QPushButton *page0_register;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer_3;
    QWidget *page1;
    QPushButton *page1_login;
    QPushButton *page1_register;
    QLabel *label_4;
    QLineEdit *page1_number;
    QLineEdit *page1_name;
    QLabel *label_5;
    QLineEdit *page1_password1;
    QLabel *label_6;
    QLineEdit *page1_password2;
    QLabel *label_7;
    QLabel *label_8;
    QComboBox *page1_sex;
    QPushButton *page1_modify;
    QPushButton *page1_cancel;
    QWidget *page2;
    QLabel *page2_welcomeAd;
    QPushButton *page2_subject;
    QPushButton *page2_mark;
    QPushButton *page2_manage;
    QPushButton *page2_back0;
    QPushButton *page2_lookinf;
    QWidget *page3;
    QLabel *page3_welcomeTea;
    QPushButton *page3_modify;
    QPushButton *page3_table;
    QPushButton *page3_mark_give;
    QPushButton *page3_back0;
    QPushButton *page3_lookinf;
    QWidget *page4;
    QLabel *page4_welcomeStu;
    QPushButton *page4_table;
    QPushButton *page4_modify;
    QPushButton *page4_back0;
    QPushButton *page4_lookinf;
    QWidget *page5;
    QTreeWidget *treeWidget;
    QPushButton *page5_back;
    QPushButton *backbutton;
    QWidget *page6;
    QPushButton *page6_delButton;
    QLabel *page6_namelabel;
    QLabel *page6_passwardlabel;
    QLabel *showname;
    QLabel *showpassward;
    QPushButton *searchButton;
    QLabel *page6_numberlabel;
    QLineEdit *numberEdit;
    QPushButton *page6_back;
    QWidget *page7;
    QLabel *page7_numberlabel;
    QLabel *page7_shownumber;
    QLabel *page7_showname;
    QPushButton *page7_back;
    QLineEdit *page7_infEdit;
    QLabel *page7_namelabel;
    QPushButton *page7_searchButton;
    QComboBox *searchcomboBox;
    QLabel *page7_classtea;
    QLabel *page7_showteaname;
    QWidget *page8;
    QPushButton *subjectRelease;
    QLabel *label_teaNum;
    QLabel *label_subNum;
    QPushButton *subjectConfirm;
    QLineEdit *subjectNumber;
    QLabel *label_subName;
    QPushButton *subjectSelectStu;
    QLineEdit *subjectTeaNumber;
    QLineEdit *subjectName;
    QPushButton *page8_back;
    QComboBox *page2_StuNumberChoose;
    QPushButton *page2_StuNumberConfirm;
    QWidget *page9;
    QPushButton *pushButton_chooseSub;
    QComboBox *page9_SubNumberChoose;
    QPushButton *page9_back;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_6;

    void setupUi(QWidget *WelcomeScene)
    {
        if (WelcomeScene->objectName().isEmpty())
            WelcomeScene->setObjectName(QString::fromUtf8("WelcomeScene"));
        WelcomeScene->setEnabled(true);
        WelcomeScene->resize(700, 600);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(WelcomeScene->sizePolicy().hasHeightForWidth());
        WelcomeScene->setSizePolicy(sizePolicy);
        WelcomeScene->setMinimumSize(QSize(700, 600));
        WelcomeScene->setMaximumSize(QSize(1200, 1800));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(8);
        WelcomeScene->setFont(font);
        formLayout = new QFormLayout(WelcomeScene);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        verticalSpacer_4 = new QSpacerItem(673, 51, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(0, QFormLayout::FieldRole, verticalSpacer_4);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_7);

        labWelcome = new QLabel(WelcomeScene);
        labWelcome->setObjectName(QString::fromUtf8("labWelcome"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labWelcome->sizePolicy().hasHeightForWidth());
        labWelcome->setSizePolicy(sizePolicy1);
        labWelcome->setMinimumSize(QSize(400, 50));
        labWelcome->setMaximumSize(QSize(400, 50));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(12);
        labWelcome->setFont(font1);
        labWelcome->setMouseTracking(true);
        labWelcome->setTextFormat(Qt::RichText);
        labWelcome->setAlignment(Qt::AlignCenter);

        horizontalLayout_4->addWidget(labWelcome);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_8);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        stackedWidget = new QStackedWidget(WelcomeScene);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setEnabled(true);
        sizePolicy.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy);
        stackedWidget->setMinimumSize(QSize(400, 400));
        stackedWidget->setMaximumSize(QSize(400, 400));
        page0 = new QWidget();
        page0->setObjectName(QString::fromUtf8("page0"));
        layoutWidget = new QWidget(page0);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 30, 383, 351));
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(85, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(213, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(149, 255, 255, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(42, 127, 127, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(56, 170, 170, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush7(QColor(170, 255, 255, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        QBrush brush8(QColor(255, 255, 220, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush9(QColor(0, 0, 0, 128));
        brush9.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_2->setPalette(palette);
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(8);
        font2.setBold(false);
        font2.setWeight(50);
        font2.setKerning(true);
        label_2->setFont(font2);
        label_2->setStyleSheet(QString::fromUtf8(""));
        label_2->setFrameShadow(QFrame::Plain);
        label_2->setTextFormat(Qt::AutoText);
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        palette1.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette1.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette1.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette1.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette1.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette1.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette1.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_3->setPalette(palette1);
        label_3->setFont(font2);
        label_3->setStyleSheet(QString::fromUtf8(""));
        label_3->setTextFormat(Qt::AutoText);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_3);


        horizontalLayout_2->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        page0_number = new QLineEdit(layoutWidget);
        page0_number->setObjectName(QString::fromUtf8("page0_number"));
        sizePolicy1.setHeightForWidth(page0_number->sizePolicy().hasHeightForWidth());
        page0_number->setSizePolicy(sizePolicy1);
        page0_number->setMinimumSize(QSize(200, 20));
        page0_number->setMaximumSize(QSize(200, 20));
        page0_number->setFont(font);

        verticalLayout_2->addWidget(page0_number);

        page0_password = new QLineEdit(layoutWidget);
        page0_password->setObjectName(QString::fromUtf8("page0_password"));
        sizePolicy1.setHeightForWidth(page0_password->sizePolicy().hasHeightForWidth());
        page0_password->setSizePolicy(sizePolicy1);
        page0_password->setMinimumSize(QSize(200, 20));
        page0_password->setMaximumSize(QSize(200, 20));
        page0_password->setFont(font);
        page0_password->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(page0_password);


        horizontalLayout_2->addLayout(verticalLayout_2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout_4->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        page0_login = new QPushButton(layoutWidget);
        page0_login->setObjectName(QString::fromUtf8("page0_login"));
        page0_login->setMinimumSize(QSize(200, 40));
        page0_login->setMaximumSize(QSize(200, 40));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(10);
        page0_login->setFont(font3);
        page0_login->setLayoutDirection(Qt::LeftToRight);

        verticalLayout_3->addWidget(page0_login);

        page0_register = new QPushButton(layoutWidget);
        page0_register->setObjectName(QString::fromUtf8("page0_register"));
        page0_register->setMinimumSize(QSize(200, 40));
        page0_register->setMaximumSize(QSize(200, 40));
        page0_register->setFont(font3);

        verticalLayout_3->addWidget(page0_register);


        horizontalLayout_3->addLayout(verticalLayout_3);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);


        verticalLayout_4->addLayout(horizontalLayout_3);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_3);

        stackedWidget->addWidget(page0);
        page1 = new QWidget();
        page1->setObjectName(QString::fromUtf8("page1"));
        page1_login = new QPushButton(page1);
        page1_login->setObjectName(QString::fromUtf8("page1_login"));
        page1_login->setGeometry(QRect(100, 320, 200, 40));
        page1_login->setMinimumSize(QSize(200, 40));
        page1_login->setMaximumSize(QSize(200, 40));
        page1_login->setFont(font3);
        page1_register = new QPushButton(page1);
        page1_register->setObjectName(QString::fromUtf8("page1_register"));
        page1_register->setGeometry(QRect(100, 270, 200, 40));
        page1_register->setMinimumSize(QSize(200, 40));
        page1_register->setMaximumSize(QSize(200, 40));
        page1_register->setFont(font3);
        page1_register->setLayoutDirection(Qt::LeftToRight);
        label_4 = new QLabel(page1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 100, 100, 20));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette2.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette2.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette2.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette2.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette2.setBrush(QPalette::Active, QPalette::Text, brush);
        palette2.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette2.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette2.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette2.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette2.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette2.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette2.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette2.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette2.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette2.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette2.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette2.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette2.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette2.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette2.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette2.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette2.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette2.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette2.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette2.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette2.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette2.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette2.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette2.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette2.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette2.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette2.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette2.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette2.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette2.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette2.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_4->setPalette(palette2);
        label_4->setFont(font2);
        label_4->setStyleSheet(QString::fromUtf8(""));
        label_4->setFrameShadow(QFrame::Plain);
        label_4->setTextFormat(Qt::AutoText);
        label_4->setAlignment(Qt::AlignCenter);
        page1_number = new QLineEdit(page1);
        page1_number->setObjectName(QString::fromUtf8("page1_number"));
        page1_number->setGeometry(QRect(150, 100, 200, 20));
        sizePolicy1.setHeightForWidth(page1_number->sizePolicy().hasHeightForWidth());
        page1_number->setSizePolicy(sizePolicy1);
        page1_number->setMinimumSize(QSize(200, 20));
        page1_number->setMaximumSize(QSize(200, 20));
        page1_number->setFont(font);
        page1_name = new QLineEdit(page1);
        page1_name->setObjectName(QString::fromUtf8("page1_name"));
        page1_name->setGeometry(QRect(100, 50, 100, 20));
        sizePolicy1.setHeightForWidth(page1_name->sizePolicy().hasHeightForWidth());
        page1_name->setSizePolicy(sizePolicy1);
        page1_name->setMinimumSize(QSize(100, 20));
        page1_name->setMaximumSize(QSize(100, 20));
        page1_name->setFont(font);
        label_5 = new QLabel(page1);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 50, 50, 20));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette3.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette3.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette3.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette3.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette3.setBrush(QPalette::Active, QPalette::Text, brush);
        palette3.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette3.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette3.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette3.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette3.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette3.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette3.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette3.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette3.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette3.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette3.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette3.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette3.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette3.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette3.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette3.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette3.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette3.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette3.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette3.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette3.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette3.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette3.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette3.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette3.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette3.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette3.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette3.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette3.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette3.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette3.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_5->setPalette(palette3);
        label_5->setFont(font2);
        label_5->setStyleSheet(QString::fromUtf8(""));
        label_5->setFrameShadow(QFrame::Plain);
        label_5->setTextFormat(Qt::AutoText);
        label_5->setAlignment(Qt::AlignCenter);
        page1_password1 = new QLineEdit(page1);
        page1_password1->setObjectName(QString::fromUtf8("page1_password1"));
        page1_password1->setGeometry(QRect(150, 150, 200, 20));
        sizePolicy1.setHeightForWidth(page1_password1->sizePolicy().hasHeightForWidth());
        page1_password1->setSizePolicy(sizePolicy1);
        page1_password1->setMinimumSize(QSize(200, 20));
        page1_password1->setMaximumSize(QSize(200, 20));
        page1_password1->setFont(font);
        page1_password1->setEchoMode(QLineEdit::Password);
        label_6 = new QLabel(page1);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(50, 150, 100, 20));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette4.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette4.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette4.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette4.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette4.setBrush(QPalette::Active, QPalette::Text, brush);
        palette4.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette4.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette4.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette4.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette4.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette4.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette4.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette4.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette4.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette4.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette4.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette4.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette4.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette4.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette4.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette4.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette4.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette4.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette4.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette4.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette4.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette4.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette4.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette4.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette4.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette4.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette4.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette4.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_6->setPalette(palette4);
        label_6->setFont(font2);
        label_6->setStyleSheet(QString::fromUtf8(""));
        label_6->setFrameShadow(QFrame::Plain);
        label_6->setTextFormat(Qt::AutoText);
        label_6->setAlignment(Qt::AlignCenter);
        page1_password2 = new QLineEdit(page1);
        page1_password2->setObjectName(QString::fromUtf8("page1_password2"));
        page1_password2->setGeometry(QRect(150, 200, 200, 20));
        sizePolicy1.setHeightForWidth(page1_password2->sizePolicy().hasHeightForWidth());
        page1_password2->setSizePolicy(sizePolicy1);
        page1_password2->setMinimumSize(QSize(200, 20));
        page1_password2->setMaximumSize(QSize(200, 20));
        page1_password2->setFont(font);
        page1_password2->setEchoMode(QLineEdit::Password);
        label_7 = new QLabel(page1);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(50, 200, 100, 20));
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette5.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette5.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette5.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette5.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette5.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette5.setBrush(QPalette::Active, QPalette::Text, brush);
        palette5.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette5.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette5.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette5.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette5.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette5.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette5.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette5.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette5.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette5.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette5.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette5.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette5.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette5.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette5.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette5.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette5.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette5.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette5.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette5.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette5.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette5.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette5.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette5.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette5.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette5.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette5.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette5.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette5.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette5.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette5.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_7->setPalette(palette5);
        label_7->setFont(font2);
        label_7->setStyleSheet(QString::fromUtf8(""));
        label_7->setFrameShadow(QFrame::Plain);
        label_7->setTextFormat(Qt::AutoText);
        label_7->setAlignment(Qt::AlignCenter);
        label_8 = new QLabel(page1);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(200, 50, 50, 20));
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette6.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette6.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette6.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        palette6.setBrush(QPalette::Active, QPalette::Dark, brush4);
        palette6.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette6.setBrush(QPalette::Active, QPalette::Text, brush);
        palette6.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette6.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette6.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette6.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette6.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette6.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette6.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette6.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette6.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette6.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette6.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette6.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette6.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette6.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette6.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette6.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette6.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette6.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette6.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette6.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette6.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush9);
#endif
        palette6.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette6.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette6.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette6.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette6.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette6.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette6.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette6.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette6.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette6.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette6.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette6.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette6.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette6.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette6.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush9);
#endif
        label_8->setPalette(palette6);
        label_8->setFont(font2);
        label_8->setStyleSheet(QString::fromUtf8(""));
        label_8->setFrameShadow(QFrame::Plain);
        label_8->setTextFormat(Qt::AutoText);
        label_8->setAlignment(Qt::AlignCenter);
        page1_sex = new QComboBox(page1);
        page1_sex->addItem(QString());
        page1_sex->addItem(QString());
        page1_sex->setObjectName(QString::fromUtf8("page1_sex"));
        page1_sex->setGeometry(QRect(250, 50, 100, 20));
        page1_sex->setEditable(true);
        page1_modify = new QPushButton(page1);
        page1_modify->setObjectName(QString::fromUtf8("page1_modify"));
        page1_modify->setGeometry(QRect(100, 230, 200, 40));
        page1_modify->setMinimumSize(QSize(200, 40));
        page1_modify->setMaximumSize(QSize(200, 40));
        page1_modify->setFont(font3);
        page1_modify->setLayoutDirection(Qt::LeftToRight);
        page1_cancel = new QPushButton(page1);
        page1_cancel->setObjectName(QString::fromUtf8("page1_cancel"));
        page1_cancel->setGeometry(QRect(100, 360, 200, 40));
        page1_cancel->setMinimumSize(QSize(200, 40));
        page1_cancel->setMaximumSize(QSize(200, 40));
        page1_cancel->setFont(font3);
        page1_cancel->setLayoutDirection(Qt::LeftToRight);
        stackedWidget->addWidget(page1);
        page2 = new QWidget();
        page2->setObjectName(QString::fromUtf8("page2"));
        page2_welcomeAd = new QLabel(page2);
        page2_welcomeAd->setObjectName(QString::fromUtf8("page2_welcomeAd"));
        page2_welcomeAd->setGeometry(QRect(0, 20, 400, 40));
        page2_welcomeAd->setMinimumSize(QSize(400, 40));
        page2_welcomeAd->setMaximumSize(QSize(400, 40));
        QFont font4;
        font4.setPointSize(10);
        page2_welcomeAd->setFont(font4);
        page2_subject = new QPushButton(page2);
        page2_subject->setObjectName(QString::fromUtf8("page2_subject"));
        page2_subject->setGeometry(QRect(100, 150, 200, 40));
        page2_subject->setMinimumSize(QSize(200, 40));
        page2_subject->setMaximumSize(QSize(200, 40));
        page2_subject->setFont(font3);
        page2_subject->setLayoutDirection(Qt::LeftToRight);
        page2_mark = new QPushButton(page2);
        page2_mark->setObjectName(QString::fromUtf8("page2_mark"));
        page2_mark->setGeometry(QRect(100, 270, 200, 40));
        page2_mark->setMinimumSize(QSize(200, 40));
        page2_mark->setMaximumSize(QSize(200, 40));
        page2_mark->setFont(font3);
        page2_mark->setLayoutDirection(Qt::LeftToRight);
        page2_manage = new QPushButton(page2);
        page2_manage->setObjectName(QString::fromUtf8("page2_manage"));
        page2_manage->setGeometry(QRect(100, 90, 200, 40));
        page2_manage->setMinimumSize(QSize(200, 40));
        page2_manage->setMaximumSize(QSize(200, 40));
        page2_manage->setFont(font3);
        page2_manage->setLayoutDirection(Qt::LeftToRight);
        page2_back0 = new QPushButton(page2);
        page2_back0->setObjectName(QString::fromUtf8("page2_back0"));
        page2_back0->setGeometry(QRect(100, 330, 201, 41));
        page2_lookinf = new QPushButton(page2);
        page2_lookinf->setObjectName(QString::fromUtf8("page2_lookinf"));
        page2_lookinf->setGeometry(QRect(100, 210, 200, 40));
        page2_lookinf->setMinimumSize(QSize(200, 40));
        page2_lookinf->setMaximumSize(QSize(200, 40));
        page2_lookinf->setFont(font3);
        page2_lookinf->setLayoutDirection(Qt::LeftToRight);
        stackedWidget->addWidget(page2);
        page3 = new QWidget();
        page3->setObjectName(QString::fromUtf8("page3"));
        page3_welcomeTea = new QLabel(page3);
        page3_welcomeTea->setObjectName(QString::fromUtf8("page3_welcomeTea"));
        page3_welcomeTea->setGeometry(QRect(0, 20, 400, 40));
        page3_welcomeTea->setMinimumSize(QSize(400, 40));
        page3_welcomeTea->setMaximumSize(QSize(400, 40));
        page3_welcomeTea->setFont(font4);
        page3_modify = new QPushButton(page3);
        page3_modify->setObjectName(QString::fromUtf8("page3_modify"));
        page3_modify->setGeometry(QRect(100, 120, 200, 40));
        page3_modify->setMinimumSize(QSize(200, 40));
        page3_modify->setMaximumSize(QSize(200, 40));
        page3_modify->setFont(font3);
        page3_modify->setLayoutDirection(Qt::LeftToRight);
        page3_table = new QPushButton(page3);
        page3_table->setObjectName(QString::fromUtf8("page3_table"));
        page3_table->setGeometry(QRect(100, 170, 200, 40));
        page3_table->setMinimumSize(QSize(200, 40));
        page3_table->setMaximumSize(QSize(200, 40));
        page3_table->setFont(font3);
        page3_table->setLayoutDirection(Qt::LeftToRight);
        page3_mark_give = new QPushButton(page3);
        page3_mark_give->setObjectName(QString::fromUtf8("page3_mark_give"));
        page3_mark_give->setGeometry(QRect(100, 270, 200, 40));
        page3_mark_give->setMinimumSize(QSize(200, 40));
        page3_mark_give->setMaximumSize(QSize(200, 40));
        page3_mark_give->setFont(font3);
        page3_mark_give->setLayoutDirection(Qt::LeftToRight);
        page3_back0 = new QPushButton(page3);
        page3_back0->setObjectName(QString::fromUtf8("page3_back0"));
        page3_back0->setGeometry(QRect(100, 330, 201, 41));
        page3_lookinf = new QPushButton(page3);
        page3_lookinf->setObjectName(QString::fromUtf8("page3_lookinf"));
        page3_lookinf->setGeometry(QRect(100, 220, 200, 40));
        page3_lookinf->setMinimumSize(QSize(200, 40));
        page3_lookinf->setMaximumSize(QSize(200, 40));
        page3_lookinf->setFont(font3);
        page3_lookinf->setLayoutDirection(Qt::LeftToRight);
        stackedWidget->addWidget(page3);
        page4 = new QWidget();
        page4->setObjectName(QString::fromUtf8("page4"));
        page4_welcomeStu = new QLabel(page4);
        page4_welcomeStu->setObjectName(QString::fromUtf8("page4_welcomeStu"));
        page4_welcomeStu->setGeometry(QRect(0, 20, 400, 40));
        page4_welcomeStu->setMinimumSize(QSize(400, 20));
        page4_welcomeStu->setMaximumSize(QSize(400, 40));
        page4_welcomeStu->setFont(font4);
        page4_table = new QPushButton(page4);
        page4_table->setObjectName(QString::fromUtf8("page4_table"));
        page4_table->setGeometry(QRect(100, 180, 200, 40));
        page4_table->setMinimumSize(QSize(200, 40));
        page4_table->setMaximumSize(QSize(200, 40));
        page4_table->setFont(font3);
        page4_table->setLayoutDirection(Qt::LeftToRight);
        page4_modify = new QPushButton(page4);
        page4_modify->setObjectName(QString::fromUtf8("page4_modify"));
        page4_modify->setGeometry(QRect(100, 110, 200, 40));
        page4_modify->setMinimumSize(QSize(200, 40));
        page4_modify->setMaximumSize(QSize(200, 40));
        page4_modify->setFont(font3);
        page4_modify->setLayoutDirection(Qt::LeftToRight);
        page4_back0 = new QPushButton(page4);
        page4_back0->setObjectName(QString::fromUtf8("page4_back0"));
        page4_back0->setGeometry(QRect(100, 310, 201, 41));
        page4_lookinf = new QPushButton(page4);
        page4_lookinf->setObjectName(QString::fromUtf8("page4_lookinf"));
        page4_lookinf->setGeometry(QRect(100, 240, 200, 40));
        page4_lookinf->setMinimumSize(QSize(200, 40));
        page4_lookinf->setMaximumSize(QSize(200, 40));
        page4_lookinf->setFont(font3);
        page4_lookinf->setLayoutDirection(Qt::LeftToRight);
        stackedWidget->addWidget(page4);
        page5 = new QWidget();
        page5->setObjectName(QString::fromUtf8("page5"));
        treeWidget = new QTreeWidget(page5);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(2, QString::fromUtf8("3"));
        __qtreewidgetitem->setText(1, QString::fromUtf8("2"));
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        treeWidget->setHeaderItem(__qtreewidgetitem);
        treeWidget->setObjectName(QString::fromUtf8("treeWidget"));
        treeWidget->setGeometry(QRect(10, 50, 391, 281));
        treeWidget->setColumnCount(3);
        page5_back = new QPushButton(page5);
        page5_back->setObjectName(QString::fromUtf8("page5_back"));
        page5_back->setGeometry(QRect(50, 360, 101, 31));
        backbutton = new QPushButton(page5);
        backbutton->setObjectName(QString::fromUtf8("backbutton"));
        backbutton->setGeometry(QRect(210, 360, 101, 31));
        stackedWidget->addWidget(page5);
        page6 = new QWidget();
        page6->setObjectName(QString::fromUtf8("page6"));
        page6_delButton = new QPushButton(page6);
        page6_delButton->setObjectName(QString::fromUtf8("page6_delButton"));
        page6_delButton->setGeometry(QRect(200, 140, 91, 41));
        page6_namelabel = new QLabel(page6);
        page6_namelabel->setObjectName(QString::fromUtf8("page6_namelabel"));
        page6_namelabel->setGeometry(QRect(30, 200, 81, 41));
        page6_passwardlabel = new QLabel(page6);
        page6_passwardlabel->setObjectName(QString::fromUtf8("page6_passwardlabel"));
        page6_passwardlabel->setGeometry(QRect(30, 250, 81, 41));
        showname = new QLabel(page6);
        showname->setObjectName(QString::fromUtf8("showname"));
        showname->setGeometry(QRect(110, 190, 111, 51));
        showpassward = new QLabel(page6);
        showpassward->setObjectName(QString::fromUtf8("showpassward"));
        showpassward->setGeometry(QRect(110, 250, 111, 51));
        searchButton = new QPushButton(page6);
        searchButton->setObjectName(QString::fromUtf8("searchButton"));
        searchButton->setGeometry(QRect(80, 140, 91, 41));
        page6_numberlabel = new QLabel(page6);
        page6_numberlabel->setObjectName(QString::fromUtf8("page6_numberlabel"));
        page6_numberlabel->setGeometry(QRect(40, 80, 71, 41));
        numberEdit = new QLineEdit(page6);
        numberEdit->setObjectName(QString::fromUtf8("numberEdit"));
        numberEdit->setGeometry(QRect(80, 80, 211, 41));
        page6_back = new QPushButton(page6);
        page6_back->setObjectName(QString::fromUtf8("page6_back"));
        page6_back->setGeometry(QRect(120, 320, 121, 41));
        stackedWidget->addWidget(page6);
        page7 = new QWidget();
        page7->setObjectName(QString::fromUtf8("page7"));
        page7_numberlabel = new QLabel(page7);
        page7_numberlabel->setObjectName(QString::fromUtf8("page7_numberlabel"));
        page7_numberlabel->setGeometry(QRect(70, 220, 81, 41));
        page7_shownumber = new QLabel(page7);
        page7_shownumber->setObjectName(QString::fromUtf8("page7_shownumber"));
        page7_shownumber->setGeometry(QRect(150, 210, 111, 51));
        page7_showname = new QLabel(page7);
        page7_showname->setObjectName(QString::fromUtf8("page7_showname"));
        page7_showname->setGeometry(QRect(150, 170, 111, 51));
        page7_back = new QPushButton(page7);
        page7_back->setObjectName(QString::fromUtf8("page7_back"));
        page7_back->setGeometry(QRect(150, 340, 121, 41));
        page7_infEdit = new QLineEdit(page7);
        page7_infEdit->setObjectName(QString::fromUtf8("page7_infEdit"));
        page7_infEdit->setGeometry(QRect(120, 60, 211, 41));
        page7_namelabel = new QLabel(page7);
        page7_namelabel->setObjectName(QString::fromUtf8("page7_namelabel"));
        page7_namelabel->setGeometry(QRect(70, 180, 81, 41));
        page7_searchButton = new QPushButton(page7);
        page7_searchButton->setObjectName(QString::fromUtf8("page7_searchButton"));
        page7_searchButton->setGeometry(QRect(150, 120, 121, 41));
        searchcomboBox = new QComboBox(page7);
        searchcomboBox->addItem(QString());
        searchcomboBox->addItem(QString());
        searchcomboBox->addItem(QString());
        searchcomboBox->setObjectName(QString::fromUtf8("searchcomboBox"));
        searchcomboBox->setGeometry(QRect(30, 60, 71, 41));
        page7_classtea = new QLabel(page7);
        page7_classtea->setObjectName(QString::fromUtf8("page7_classtea"));
        page7_classtea->setGeometry(QRect(70, 260, 81, 41));
        page7_showteaname = new QLabel(page7);
        page7_showteaname->setObjectName(QString::fromUtf8("page7_showteaname"));
        page7_showteaname->setGeometry(QRect(150, 260, 111, 51));
        stackedWidget->addWidget(page7);
        page8 = new QWidget();
        page8->setObjectName(QString::fromUtf8("page8"));
        subjectRelease = new QPushButton(page8);
        subjectRelease->setObjectName(QString::fromUtf8("subjectRelease"));
        subjectRelease->setGeometry(QRect(40, 300, 121, 41));
        label_teaNum = new QLabel(page8);
        label_teaNum->setObjectName(QString::fromUtf8("label_teaNum"));
        label_teaNum->setGeometry(QRect(30, 80, 39, 25));
        label_subNum = new QLabel(page8);
        label_subNum->setObjectName(QString::fromUtf8("label_subNum"));
        label_subNum->setGeometry(QRect(30, 130, 56, 25));
        subjectConfirm = new QPushButton(page8);
        subjectConfirm->setObjectName(QString::fromUtf8("subjectConfirm"));
        subjectConfirm->setGeometry(QRect(40, 240, 121, 41));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(subjectConfirm->sizePolicy().hasHeightForWidth());
        subjectConfirm->setSizePolicy(sizePolicy2);
        subjectNumber = new QLineEdit(page8);
        subjectNumber->setObjectName(QString::fromUtf8("subjectNumber"));
        subjectNumber->setGeometry(QRect(100, 130, 208, 25));
        label_subName = new QLabel(page8);
        label_subName->setObjectName(QString::fromUtf8("label_subName"));
        label_subName->setGeometry(QRect(30, 180, 65, 25));
        subjectSelectStu = new QPushButton(page8);
        subjectSelectStu->setObjectName(QString::fromUtf8("subjectSelectStu"));
        subjectSelectStu->setGeometry(QRect(190, 240, 121, 41));
        subjectTeaNumber = new QLineEdit(page8);
        subjectTeaNumber->setObjectName(QString::fromUtf8("subjectTeaNumber"));
        subjectTeaNumber->setGeometry(QRect(100, 80, 208, 25));
        subjectName = new QLineEdit(page8);
        subjectName->setObjectName(QString::fromUtf8("subjectName"));
        subjectName->setGeometry(QRect(100, 180, 208, 25));
        page8_back = new QPushButton(page8);
        page8_back->setObjectName(QString::fromUtf8("page8_back"));
        page8_back->setGeometry(QRect(190, 300, 121, 41));
        page2_StuNumberChoose = new QComboBox(page8);
        page2_StuNumberChoose->setObjectName(QString::fromUtf8("page2_StuNumberChoose"));
        page2_StuNumberChoose->setGeometry(QRect(20, 20, 241, 29));
        page2_StuNumberConfirm = new QPushButton(page8);
        page2_StuNumberConfirm->setObjectName(QString::fromUtf8("page2_StuNumberConfirm"));
        page2_StuNumberConfirm->setGeometry(QRect(280, 20, 91, 32));
        stackedWidget->addWidget(page8);
        page9 = new QWidget();
        page9->setObjectName(QString::fromUtf8("page9"));
        pushButton_chooseSub = new QPushButton(page9);
        pushButton_chooseSub->setObjectName(QString::fromUtf8("pushButton_chooseSub"));
        pushButton_chooseSub->setGeometry(QRect(280, 50, 91, 32));
        page9_SubNumberChoose = new QComboBox(page9);
        page9_SubNumberChoose->setObjectName(QString::fromUtf8("page9_SubNumberChoose"));
        page9_SubNumberChoose->setGeometry(QRect(20, 50, 241, 29));
        page9_back = new QPushButton(page9);
        page9_back->setObjectName(QString::fromUtf8("page9_back"));
        page9_back->setGeometry(QRect(130, 280, 121, 41));
        stackedWidget->addWidget(page9);

        horizontalLayout->addWidget(stackedWidget);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        formLayout->setLayout(2, QFormLayout::FieldRole, horizontalLayout);

        verticalSpacer_6 = new QSpacerItem(673, 51, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(3, QFormLayout::FieldRole, verticalSpacer_6);


        retranslateUi(WelcomeScene);

        stackedWidget->setCurrentIndex(1);
        page1_sex->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(WelcomeScene);
    } // setupUi

    void retranslateUi(QWidget *WelcomeScene)
    {
        WelcomeScene->setWindowTitle(QCoreApplication::translate("WelcomeScene", "\346\225\231\345\212\241\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        labWelcome->setText(QCoreApplication::translate("WelcomeScene", "\346\225\231\345\212\241\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        label_2->setText(QCoreApplication::translate("WelcomeScene", "\345\255\246\345\217\267\357\274\210\345\267\245\345\217\267\357\274\211\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("WelcomeScene", "\345\257\206\347\240\201\357\274\232", nullptr));
        page0_password->setText(QString());
        page0_login->setText(QCoreApplication::translate("WelcomeScene", "\347\231\273\345\275\225", nullptr));
        page0_register->setText(QCoreApplication::translate("WelcomeScene", "\346\262\241\346\234\211\350\264\246\346\210\267\357\274\237\345\211\215\345\276\200\346\263\250\345\206\214", nullptr));
        page1_login->setText(QCoreApplication::translate("WelcomeScene", "\345\267\262\346\234\211\350\264\246\346\210\267\357\274\237\350\277\224\345\233\236\347\231\273\351\231\206", nullptr));
        page1_register->setText(QCoreApplication::translate("WelcomeScene", "\347\241\256\350\256\244\346\263\250\345\206\214", nullptr));
        label_4->setText(QCoreApplication::translate("WelcomeScene", "\345\255\246\345\217\267\357\274\210\345\267\245\345\217\267\357\274\211\357\274\232", nullptr));
        label_5->setText(QCoreApplication::translate("WelcomeScene", "\345\247\223\345\220\215\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("WelcomeScene", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("WelcomeScene", "\350\257\267\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", nullptr));
        label_8->setText(QCoreApplication::translate("WelcomeScene", "\346\200\247\345\210\253\357\274\232", nullptr));
        page1_sex->setItemText(0, QCoreApplication::translate("WelcomeScene", "\347\224\267", nullptr));
        page1_sex->setItemText(1, QCoreApplication::translate("WelcomeScene", "\345\245\263", nullptr));

        page1_sex->setCurrentText(QCoreApplication::translate("WelcomeScene", "\347\224\267", nullptr));
        page1_modify->setText(QCoreApplication::translate("WelcomeScene", "\347\241\256\350\256\244\344\277\256\346\224\271", nullptr));
        page1_cancel->setText(QCoreApplication::translate("WelcomeScene", "\345\217\226\346\266\210", nullptr));
        page2_welcomeAd->setText(QCoreApplication::translate("WelcomeScene", "  \351\252\214\350\257\201\346\210\220\345\212\237\357\274\214\346\202\250\347\232\204\350\272\253\344\273\275\346\230\257\347\256\241\347\220\206\345\221\230\357\274\214\346\254\242\350\277\216\346\202\250\357\274\201", nullptr));
        page2_subject->setText(QCoreApplication::translate("WelcomeScene", "\345\256\211\346\216\222\350\257\276\347\250\213", nullptr));
        page2_mark->setText(QCoreApplication::translate("WelcomeScene", "\345\217\221\345\270\203\346\210\220\347\273\251", nullptr));
        page2_manage->setText(QCoreApplication::translate("WelcomeScene", "\347\256\241\347\220\206\347\224\250\346\210\267", nullptr));
        page2_back0->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\231\273\345\275\225\347\225\214\351\235\242", nullptr));
        page2_lookinf->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213\344\277\241\346\201\257", nullptr));
        page3_welcomeTea->setText(QCoreApplication::translate("WelcomeScene", "  \351\252\214\350\257\201\346\210\220\345\212\237\357\274\214\346\202\250\347\232\204\350\272\253\344\273\275\346\230\257\350\200\201\345\270\210\357\274\214\346\254\242\350\277\216\346\202\250\357\274\201", nullptr));
        page3_modify->setText(QCoreApplication::translate("WelcomeScene", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        page3_table->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213\350\257\276\350\241\250", nullptr));
        page3_mark_give->setText(QCoreApplication::translate("WelcomeScene", "\347\273\231\345\207\272\346\210\220\347\273\251", nullptr));
        page3_back0->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\231\273\345\275\225\347\225\214\351\235\242", nullptr));
        page3_lookinf->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213\344\277\241\346\201\257", nullptr));
        page4_welcomeStu->setText(QCoreApplication::translate("WelcomeScene", "  \351\252\214\350\257\201\346\210\220\345\212\237\357\274\214\346\202\250\347\232\204\350\272\253\344\273\275\346\230\257\345\255\246\347\224\237\357\274\214\346\254\242\350\277\216\346\202\250\357\274\201", nullptr));
        page4_table->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213\350\257\276\350\241\250", nullptr));
        page4_modify->setText(QCoreApplication::translate("WelcomeScene", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        page4_back0->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\231\273\345\275\225\347\225\214\351\235\242", nullptr));
        page4_lookinf->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213\344\277\241\346\201\257", nullptr));
        page5_back->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\224\250\346\210\267\347\225\214\351\235\242", nullptr));
        backbutton->setText(QCoreApplication::translate("WelcomeScene", "\345\217\221\345\270\203\350\257\276\347\250\213", nullptr));
        page6_delButton->setText(QCoreApplication::translate("WelcomeScene", "\345\210\240\351\231\244\347\224\250\346\210\267", nullptr));
        page6_namelabel->setText(QCoreApplication::translate("WelcomeScene", "\345\247\223\345\220\215\357\274\232", nullptr));
        page6_passwardlabel->setText(QCoreApplication::translate("WelcomeScene", "\345\257\206\347\240\201\357\274\232", nullptr));
        showname->setText(QCoreApplication::translate("WelcomeScene", "NULL", nullptr));
        showpassward->setText(QCoreApplication::translate("WelcomeScene", "NULL", nullptr));
        searchButton->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\346\211\276", nullptr));
        page6_numberlabel->setText(QCoreApplication::translate("WelcomeScene", "\345\255\246\345\217\267:", nullptr));
        page6_back->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\256\241\347\220\206\345\221\230\347\225\214\351\235\242", nullptr));
        page7_numberlabel->setText(QCoreApplication::translate("WelcomeScene", "\345\255\246\345\217\267\357\274\232", nullptr));
        page7_shownumber->setText(QCoreApplication::translate("WelcomeScene", "NULL", nullptr));
        page7_showname->setText(QCoreApplication::translate("WelcomeScene", "NULL", nullptr));
        page7_back->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\224\250\346\210\267\347\225\214\351\235\242", nullptr));
        page7_namelabel->setText(QCoreApplication::translate("WelcomeScene", "\345\247\223\345\220\215\357\274\232", nullptr));
        page7_searchButton->setText(QCoreApplication::translate("WelcomeScene", "\346\237\245\347\234\213", nullptr));
        searchcomboBox->setItemText(0, QCoreApplication::translate("WelcomeScene", "\345\255\246\345\217\267/\345\267\245\345\217\267", nullptr));
        searchcomboBox->setItemText(1, QCoreApplication::translate("WelcomeScene", "\345\247\223\345\220\215", nullptr));
        searchcomboBox->setItemText(2, QCoreApplication::translate("WelcomeScene", "\350\257\276\347\250\213\345\220\215", nullptr));

        page7_classtea->setText(QCoreApplication::translate("WelcomeScene", "\344\273\273\350\257\276\350\200\201\345\270\210\357\274\232", nullptr));
        page7_showteaname->setText(QCoreApplication::translate("WelcomeScene", "NULL", nullptr));
        subjectRelease->setText(QCoreApplication::translate("WelcomeScene", "\345\217\221\345\270\203\350\257\276\347\250\213", nullptr));
        label_teaNum->setText(QCoreApplication::translate("WelcomeScene", "\345\267\245\345\217\267\357\274\232", nullptr));
        label_subNum->setText(QCoreApplication::translate("WelcomeScene", "\350\257\276\347\250\213\345\272\217\345\217\267:", nullptr));
        subjectConfirm->setText(QCoreApplication::translate("WelcomeScene", "\347\241\256\345\256\232\350\257\276\347\250\213", nullptr));
        label_subName->setText(QCoreApplication::translate("WelcomeScene", "\350\257\276\347\250\213\345\220\215\347\247\260\357\274\232", nullptr));
        subjectSelectStu->setText(QCoreApplication::translate("WelcomeScene", "\351\200\211\346\213\251\345\255\246\347\224\237", nullptr));
        page8_back->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\256\241\347\220\206\345\221\230\347\225\214\351\235\242", nullptr));
        page2_StuNumberConfirm->setText(QCoreApplication::translate("WelcomeScene", "\347\241\256\350\256\244\351\200\211\346\213\251", nullptr));
        pushButton_chooseSub->setText(QCoreApplication::translate("WelcomeScene", "\351\200\211\346\213\251", nullptr));
        page9_back->setText(QCoreApplication::translate("WelcomeScene", "\350\277\224\345\233\236\347\256\241\347\220\206\345\221\230\347\225\214\351\235\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WelcomeScene: public Ui_WelcomeScene {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WELCOMESCENE_H
