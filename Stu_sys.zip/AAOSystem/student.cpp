#include "student.h"
#include <QFile>
#include <QTextStream>
#include <QIODevice>
#include <QDebug>

Student::Student(QString tempNumber, QString tempName, QString tempSex, QString tempPassword): User(tempNumber, tempName, tempSex, tempPassword)
{
    QString filePath = "./student/";
    QFile file(filePath.append(tempNumber+".txt"));
    if(! file.open(QIODevice::ReadWrite|QIODevice::Text))
    {
        qDebug()<<"warning";
    }
    QTextStream txtWrite(&file);
    txtWrite<<tempNumber<<' '<<tempName<<' '<<tempSex<<' '<<tempPassword<<'\n';
    file.close();
}

void Student::checkSubject()
{
    QString filePath = "./student/";
    QFile file(filePath.append(number+".txt"));
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    QTextStream subjectRead(&file);
    subjectRead.readLine();
    QStringList tempList;
    do
    {
        tempList = subjectRead.readLine().split(' ');
        if(tempList[0] == "")
            break;
        qDebug()<<"课程"<<tempList[1]<<"教师"<<tempList[3];
    }while(1);
    file.close();
}

void Student::modifyInfo(QString tempName, QString tempSex, QString tempPassword)
{
    User::modifyInfo(tempName, tempSex, tempPassword);
    QString filePath = "./student/";
    filePath = filePath.append(number+".txt");
    QFile fileRead(filePath);
    fileRead.open(QIODevice::ReadOnly|QIODevice::Text);
    QTextStream txtRead(&fileRead);
    QString allData = txtRead.readAll();
    QStringList list = allData.split('\n');
    list[0] = number + ' ' + tempName + ' ' + tempSex + ' ' + tempPassword;
    fileRead.close();
    QFile fileWrite(filePath);
    fileWrite.open(QIODevice::WriteOnly|QIODevice::Text);
    QTextStream txtWrite(&fileWrite);
    for(int i = 0; list[i] != ""; i++)
    {
        txtWrite<<list[i]<<'\n';
    }
    fileWrite.close();
}
