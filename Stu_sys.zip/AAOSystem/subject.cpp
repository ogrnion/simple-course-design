﻿#include "subject.h"
#include <QFile>
#include <QTextStream>
#include <QIODevice>
#include <QMessageBox>
#include <QDebug>

Subject::Subject(QString tempNumber)
{
    number = tempNumber;
    reload();
}
Subject::Subject(QString tempNumber, QString tempName, QString tempTeaName, int size)
{
    number = tempNumber;
    name = tempName;
    tea = tempTeaName;
    studentsize = size;
    for(int i = 0; i < studentsize; i++)
    {
        stu[i] = " ";
        mark[i] = -1;
    }
}

void Subject::setTea(QString teaNumber)
{
    tea = teaNumber;
}

void Subject::addStudent(QString studentNum)//stuNumber[], int n
{
    QString filePath = QString("./subject/").append(number+".txt");
    QFile subjectFile(filePath);
    subjectFile.open(QIODevice::ReadWrite|QIODevice::Text);
    QTextStream txt(&subjectFile);
    QStringList tempList;
    txt.readLine();
    do{
        tempList = txt.readLine().split(' ');
        if(tempList[0] == "")
            break;
        else if (tempList[0] == studentNum)
            break;
    }while(1);
    if(tempList[0] == "")
        txt<<studentNum<<' '<<-1<<'\n';
    subjectFile.close();

    //for(int i = 0; i<n && i<studentsize; i++)
    //{
      //  stu[i] = stuNumber[i];
    //}
}

void Subject::addMark(QString stuNumber[], int tempMark[])
{
    for(int i = 0; i < studentsize; i++)
        if(stu[i] == stuNumber)
        {
            mark[i] = tempMark[i];
            break;
        }
}

void Subject::reload()
{
    QString path = "./subject/" + number + ".txt";
    QFile file(path);
    file.open(QIODevice::ReadOnly|QIODevice::Text);
    QTextStream reload(&file);
    QStringList tempList = reload.readLine().split(' ');
    number = tempList[0];
    name = tempList[1];
    tea = tempList[2];
    int index = 0;
    do
    {
        tempList = reload.readLine().split(' ');
        if(tempList[0] == "")
            break;      
        stu[index] = tempList[0];
        mark[index] = tempList[1].toInt();
        index++;
    }while(1);
    studentsize = index;
    file.close();
}

void Subject::record()
{
    QString filePath = "./subject/";
    QFile file0("./subject/subjectInfo.txt");
    if(! file0.open(QIODevice::ReadWrite|QIODevice::Text))
    {
        qDebug()<<"warning";
    }
    else{
        QStringList temp;
        QTextStream txtWrite(&file0);
        do
        {
            temp = txtWrite.readLine().split(' ');
        }while (temp[0] != number && temp[0]!="");
        if(temp[0] == "")
            txtWrite<<number<<' '<<name<<' '<<tea<<'\n';
    }
    file0.close();
    QFile file1(filePath.append(number+".txt"));
    if(! file1.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        qDebug()<<"warning";
    }
    QTextStream txtWrite(&file1);
    txtWrite<<number<<' '<<name<<' '<<tea<<'\n';
    for(int i = 0; i < studentsize; i++)
    {
        if(stu[i] == " ")
            break;
        txtWrite<<stu[i]<<" "<<mark[i]<<'\n';
    }
    file1.close();
}

Subject::~Subject()
{
}
